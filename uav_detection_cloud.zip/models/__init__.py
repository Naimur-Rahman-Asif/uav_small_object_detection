# models/__init__.py
from .yolov8_enhanced import EnhancedYOLOv8

__all__ = ['EnhancedYOLOv8']
