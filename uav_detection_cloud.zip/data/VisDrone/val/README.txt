Upload your VisDrone val dataset here:
  - images/ folder
  - annotations/ folder
