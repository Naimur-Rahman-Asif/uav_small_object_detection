Upload your VisDrone test dataset here:
  - images/ folder
  - annotations/ folder
