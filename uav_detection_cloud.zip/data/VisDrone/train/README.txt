Upload your VisDrone train dataset here:
  - images/ folder
  - annotations/ folder
